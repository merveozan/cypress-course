// Cypress adds chai expect and assert to global
declare var expect: Chai.ExpectStatic
declare var assert: Chai.AssertStatic
