import { keyBy } from "./index";
export = keyBy;
