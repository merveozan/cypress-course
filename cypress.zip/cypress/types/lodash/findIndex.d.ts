import { findIndex } from "./index";
export = findIndex;
