import { partialRight } from "./index";
export = partialRight;
