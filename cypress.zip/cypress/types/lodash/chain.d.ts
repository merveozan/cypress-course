import { chain } from "./index";
export = chain;
