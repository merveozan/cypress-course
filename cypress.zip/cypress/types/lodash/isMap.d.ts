import { isMap } from "./index";
export = isMap;
