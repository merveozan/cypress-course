import { now } from "./index";
export = now;
