import { toPath } from "./index";
export = toPath;
