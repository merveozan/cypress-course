import { toPlainObject } from "./index";
export = toPlainObject;
