import { sortBy } from "../fp";
export = sortBy;
