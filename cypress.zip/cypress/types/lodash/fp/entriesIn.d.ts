import { entriesIn } from "../fp";
export = entriesIn;
