import { flowRight } from "../fp";
export = flowRight;
