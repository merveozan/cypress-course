import { pullAt } from "../fp";
export = pullAt;
