import { rangeStepRight } from "../fp";
export = rangeStepRight;
