import { sortedLastIndexOf } from "./index";
export = sortedLastIndexOf;
