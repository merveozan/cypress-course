import { throttle } from "./index";
export = throttle;
