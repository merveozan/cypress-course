import { startCase } from "./index";
export = startCase;
