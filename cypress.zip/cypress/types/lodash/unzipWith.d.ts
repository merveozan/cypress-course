import { unzipWith } from "./index";
export = unzipWith;
