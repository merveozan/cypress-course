import { isArrayBuffer } from "./index";
export = isArrayBuffer;
