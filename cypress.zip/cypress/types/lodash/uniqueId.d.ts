import { uniqueId } from "./index";
export = uniqueId;
