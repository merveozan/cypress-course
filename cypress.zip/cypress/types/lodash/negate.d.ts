import { negate } from "./index";
export = negate;
