import { wrap } from "./index";
export = wrap;
