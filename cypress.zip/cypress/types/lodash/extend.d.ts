import { extend } from "./index";
export = extend;
