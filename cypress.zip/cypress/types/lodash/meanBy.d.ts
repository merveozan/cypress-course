import { meanBy } from "./index";
export = meanBy;
