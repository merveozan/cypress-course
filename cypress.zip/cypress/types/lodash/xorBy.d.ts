import { xorBy } from "./index";
export = xorBy;
