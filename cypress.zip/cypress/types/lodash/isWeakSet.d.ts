import { isWeakSet } from "./index";
export = isWeakSet;
