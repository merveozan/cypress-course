import { isNil } from "./index";
export = isNil;
