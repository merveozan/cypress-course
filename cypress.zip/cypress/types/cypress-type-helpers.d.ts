// type helpers
declare namespace Cypress {
   type Nullable<T> = T | null
}
